package org.javi.dd5;

public enum Focus {
    
    Stone, Magic, Alchemy, Tech;
    
}