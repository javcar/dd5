package org.javi.dd5;

import java.util.ArrayList;
import java.util.List;

public abstract class Character {

    private int hitPoints = 0; /* Actual hit points */
    private boolean isRested = false; /* True if long rested */

    private boolean isCriticalHitWhithMeleeWeapon = false; /* Trie if just scored a critical hit with a melee weapon, updated every round */
    private boolean canRollExtraDiceOnMeleeDamage = false; /* roll one of the weapon’s damage dice one additional time */    

    private Armor armorEquiped;

    private Abilities abilities = new Abilities();
    private Race race;
    private List<Profession> professions = new ArrayList<Profession>();
    private List<Ability> proficientSavingThrows = new ArrayList<Ability>();
    private List<Skill> proficientSkills = new ArrayList<Skill>();
    private List<Action> availableActions = new ArrayList<Action>();

    public int getHitPoints() {
        return this.hitPoints;
    }

    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    public boolean getIsRested() {
        return this.isRested;
    }

    public boolean getIsCriticalHitWhithMeleeWeapon() {
        return isCriticalHitWhithMeleeWeapon;
    }

    public boolean getCanRollExtraDiceOnMeleeDamage() {
        return this.canRollExtraDiceOnMeleeDamage;
    }

    public void setCanRollExtraDiceOnMeleeDamage(boolean canRollExtraDiceOnMeleeDamage) {
        this.canRollExtraDiceOnMeleeDamage = canRollExtraDiceOnMeleeDamage;
    }

    public Armor getArmorEquiped() {
        return this.armorEquiped;
    }
    
    public Abilities getAbilities() {
        return this.abilities;
    }

    public Race getRace() {
        return this.race;
    }

    public List<Profession> getProfessions() {
        return this.professions;
    }

    public List<Ability> getProficientSavingThrows() {
        return this.proficientSavingThrows;
    }

    public List<Skill> getProficientSkills() {
        return this.proficientSkills;
    }

    public List<Action> getAvailableActions() {
        return this.availableActions;
    }

    public boolean getIsActionAvailable(Action actionAvailable) {
        return this.availableActions.stream().anyMatch(action -> action.equals(actionAvailable));
    }

    public int getSpeed() {
        return 0;
    }
    
}