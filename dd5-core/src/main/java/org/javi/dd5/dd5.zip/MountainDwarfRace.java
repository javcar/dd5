package org.javi.dd5;

public class MountainDwarfRace extends DwarfRace {
    
    public MountainDwarfRace() {
        
        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Strength, +2);

        /* Other traits */
        grantDwarvenArmorTraining();

    }

    private void grantDwarvenArmorTraining() {
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Light));
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Medium));
    }

}