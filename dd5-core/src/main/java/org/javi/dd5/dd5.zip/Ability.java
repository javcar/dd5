package org.javi.dd5;

public enum Ability {

    Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma;
    
}