package org.javi.dd5;

public class HillDwarfRace extends DwarfRace {
    
    public HillDwarfRace() {
        
        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Wisdom, +1);

        /* Other traits */
        grantDwarvenToughness();

    }

    private void grantDwarvenToughness() {
        setHitPointsBonusWhenLevelUp(1);
    }


}