package org.javi.dd5;

public class ElfRace extends Race {

    public ElfRace() {

        setDarkVisionRange(60);
        setAdultAge(100);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Dexterity, +2);

        /* Languages */
        grantLanguages();

        /* Other traits */
        grantKeenSenses();
        grantFeyAncestry();
        grantTrance();

    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);
        getGrantedLanguages().add(Language.Elvish);
    }

    private void grantKeenSenses() {
        getGrantedSkillProficiencies().add(Skill.Perception);
    }

    private void grantFeyAncestry() {
        getGrantedSavingThrowAdvantages().add(Damage.Charm);
        getGrantedImmunities().add(Damage.MagicalSleep);
    }

    private void grantTrance() {
        setFullRestTime(4);
    }
    
}