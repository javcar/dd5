package org.javi.dd5;

public class FocusedSkill {

    private Skill skill;
    private Focus focus;

    public FocusedSkill(Skill skill, Focus focus) {
        this.skill = skill;
        this.focus = focus;
    }

    public Skill getSkill() {
        return this.skill;
    }

    public Focus getFocus() {
        return this.focus;
    }

    public String toString() {
        return this.skill.toString() + " (" + this.focus.toString() + ")";
    }
    
}