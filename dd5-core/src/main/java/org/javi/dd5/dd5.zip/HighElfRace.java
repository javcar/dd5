package org.javi.dd5;

public class HighElfRace extends ElfRace {

    public HighElfRace() {

        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Intelligence, +1);

        /* Other traits */
        grantElfWeaponTraining();
        grantCantrip();
        grantExtraLanguage();

    }

    private void grantElfWeaponTraining() {
        getGrantedWeaponProficiencies().add(Weapon.LongSword);
        getGrantedWeaponProficiencies().add(Weapon.ShortSword);
        getGrantedWeaponProficiencies().add(Weapon.ShortBow);
        getGrantedWeaponProficiencies().add(Weapon.LongBow);
    }

    private void grantCantrip() {
        setCantripSlots(1);
        setAbilityForCantrip(Ability.Intelligence);
        setSpellCategoryForCantrip(SpellCategory.Wizard);
    }

    private void grantExtraLanguage() {
        setLanguageSlots(1);
    }
    
}