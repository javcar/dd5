package org.javi.dd5;

public class GnomeRace extends Race {

    public GnomeRace() {

        setSpeed(25);
        setSize(Size.Small);
        setDarkVisionRange(60);
        setAdultAge(40);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Intelligence, +2);

        /* Languages */
        grantLanguages();

        /* Other traits */
        grantGnomeCunning();

    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);
        getGrantedLanguages().add(Language.Gnomish);
    }

    private void grantGnomeCunning() {
        getGrantedFocusedSavingThrowAdvantages().add(new FocusedAbility(Ability.Intelligence, Focus.Magic));
        getGrantedFocusedSavingThrowAdvantages().add(new FocusedAbility(Ability.Wisdom, Focus.Magic));
        getGrantedFocusedSavingThrowAdvantages().add(new FocusedAbility(Ability.Charisma, Focus.Magic));
    }
    
}