package org.javi.dd5;

public class RelentlessEnduranceSpecialTrait extends SpecialTrait {
    
    @Override
    public boolean canActivate() {        
        return this.getCharges() > 0 && 
            this.getCharacter().getHitPoints() == 0;
    }

    @Override
    public void activate() {        
        this.getCharacter().setHitPoints(1);
        this.setCharges(this.getCharges() - 1);
    }

    @Override
    public boolean canRestore() {
        return this.getCharacter().getIsRested();
    }
    
}