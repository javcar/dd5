package org.javi.dd5;

public enum WeaponCategory {

    Simple, Martial;
    
}