package org.javi.dd5;

public class WeaponQty {
    private Weapon weapon;
    private int qty;
    
    public WeaponQty(Weapon weapon) {
        this.weapon = weapon;
        this.qty = 1;
    }

    public WeaponQty(Weapon weapon, int qty) {
        this.weapon = weapon;
        this.qty = qty;
    }

    public Weapon getWeapon() {
        return this.weapon;
    }

    public int getQty() {
        return this.qty;
    }
}