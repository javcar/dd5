package org.javi.dd5;

public class SavageAttacksSpecialTrait extends SpecialTrait {
    
    @Override
    public boolean canActivate() {        
        return this.getCharges() > 0 && 
            this.getCharacter().getIsCriticalHitWhithMeleeWeapon();
    }

    @Override
    public void activate() {        
        this.getCharacter().setCanRollExtraDiceOnMeleeDamage(true);        
        this.setCharges(this.getCharges() - 1);
    }

    @Override
    public boolean canRestore() {
        return true;
    }
    
}