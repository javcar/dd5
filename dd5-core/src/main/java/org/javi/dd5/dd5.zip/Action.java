package org.javi.dd5;

public enum Action {

    Bonus;
    
}