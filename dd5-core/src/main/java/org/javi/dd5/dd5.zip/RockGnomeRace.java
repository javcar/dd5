package org.javi.dd5;

public class RockGnomeRace extends GnomeRace {

    public RockGnomeRace() {

        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Constitution, +1);

        /* Other traits */
        grantArtificierLore();
        grantTinker();        

    }

    private void grantArtificierLore() {
        getGrantedFocusedSkillProficiencies().add(new FocusedSkill(Skill.History, Focus.Magic)); /* Doble bonus */
        getGrantedFocusedSkillProficiencies().add(new FocusedSkill(Skill.History, Focus.Alchemy)); /* Doble bonus */
        getGrantedFocusedSkillProficiencies().add(new FocusedSkill(Skill.History, Focus.Tech)); /* Doble bonus */
    }

    private void grantTinker() {
        getGrantedToolProficiencies().add(Tool.Tinker);
    }
    
}