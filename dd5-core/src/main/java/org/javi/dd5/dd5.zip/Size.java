package org.javi.dd5;

public enum Size {

    Small, Medium, Large;

}