package org.javi.dd5;

public class LightfootHalflingRace extends HalflingRace {

    public LightfootHalflingRace() {

        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Charisma, +1);

        /* Other traits */
        grantNaturallyStealthy();

    }

    private void grantNaturallyStealthy() {
        setCanHideWhenObscuredByLargerCreature(true);
    }
    
}