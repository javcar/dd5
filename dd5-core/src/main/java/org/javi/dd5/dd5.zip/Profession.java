package org.javi.dd5;

import java.util.ArrayList;
import java.util.List;

public abstract class Profession {

    private int hitDice;

    private boolean grantedShieldProficiency = false;

    private int skillSlots = 0;

    private List<Ability> grantedPrimaryAbilities = new ArrayList<Ability>();
    private List<Ability> grantedSavingThrowProficiencies = new ArrayList<Ability>();
    private List<Armor> grantedArmorProficiencies = new ArrayList<Armor>();    
    private List<Weapon> grantedWeaponProficiencies = new ArrayList<Weapon>();

    private List<Skill> offeredSkillProficiencies = new ArrayList<Skill>();

    public int getHitDice() {
        return this.hitDice;
    }

    public void setHitDice(int hitDice) {
        this.hitDice = hitDice;
    }

    public boolean getGrantedShieldProficiency() {
        return this.grantedShieldProficiency;
    }

    public void setGrantedShieldProficiency(boolean grantedShieldProficiency) {
        this.grantedShieldProficiency = grantedShieldProficiency;
    }

    public int getSkillSlots() {
        return this.skillSlots;
    }

    public void setSkillSlots(int skillSlots) {
        this.skillSlots = skillSlots;
    }

    public List<Ability> getGrantedPrimaryAbilities() {
        return this.grantedPrimaryAbilities;
    }

    public List<Ability> getGrantedSavingThrowProficiencies() {
        return this.grantedSavingThrowProficiencies;
    }

    public List<Armor> getGrantedArmorProficiencies() {
        return this.grantedArmorProficiencies;
    }

    public List<Weapon> getGrantedWeaponProficiencies() {
        return this.grantedWeaponProficiencies;
    }

    public List<Skill> getOfferedSkillProficiencies() {
        return this.offeredSkillProficiencies;
    }
    
}