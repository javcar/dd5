package org.javi.dd5;

public class HalfElfRace extends Race {

    public HalfElfRace() {

        setDarkVisionRange(60);
        setAdultAge(20);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Charisma, +2);

        /* Languages */
        grantLanguages();

        /* Other traits */
        ExtraAbilityAdjustments();
        grantFeyAncestry();
        grantSkillVersatility();

    }

    private void ExtraAbilityAdjustments() {
        setAbilitySlotsForOnePointUpAdjustment(2);
    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);
        getGrantedLanguages().add(Language.Elvish);
    }

    private void grantFeyAncestry() {
        getGrantedSavingThrowAdvantages().add(Damage.Charm);
        getGrantedImmunities().add(Damage.MagicalSleep);
    }

    private void grantSkillVersatility() {
        setSkillSlots(2);
    }
    
}