package org.javi.dd5;

public class BarbarianProfession extends Profession {

    public BarbarianProfession() {
        
        setHitDice(12);

        getGrantedPrimaryAbilities().add(Ability.Strength);

        getGrantedSavingThrowProficiencies().add(Ability.Strength);
        getGrantedSavingThrowProficiencies().add(Ability.Constitution);
        
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Light));
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Medium));

        setGrantedShieldProficiency(true);

        getGrantedWeaponProficiencies().addAll(Weapon.getWeapons(WeaponCategory.Simple));
        getGrantedWeaponProficiencies().addAll(Weapon.getWeapons(WeaponCategory.Martial));

        setSkillSlots(2);
        getOfferedSkillProficiencies().add(Skill.AnimalHandling);
        getOfferedSkillProficiencies().add(Skill.Athletics);
        getOfferedSkillProficiencies().add(Skill.Intimidation);
        getOfferedSkillProficiencies().add(Skill.Nature);
        getOfferedSkillProficiencies().add(Skill.Perception);
        getOfferedSkillProficiencies().add(Skill.Survival);        

    }
    
}