package org.javi.dd5;

public class App 
{
    public static void main( String[] args )
    {
        Race race = new HalfOrcRace();
        
        show("Race", race.getClass().getSimpleName());
        show("Speed", String.valueOf(race.getSpeed()));
        show("Size", String.valueOf(race.getSize()));
        show("Dark vision", (race.getDarkVisionRange() == 0 ? "No" : String.valueOf(race.getDarkVisionRange())));
        show("Adult age", String.valueOf(race.getAdultAge()));
        
        show("Hit points bonus when level up", String.valueOf(race.getHitPointsBonusWhenLevelUp()));
        show("Full rest time", String.valueOf(race.getFullRestTime()));        
        show("Language slots", String.valueOf(race.getLanguageSlots()));
        show("Ability slots for one point up adjustment", String.valueOf(race.getAbilitySlotsForOnePointUpAdjustment()));
        show("Skill slots", String.valueOf(race.getSkillSlots()));

        show("Can hide when lightly obscured by natural phenomena", String.valueOf(race.getCanHideWhenLightlyObscuredByNaturalPhenomena() ? "Yes" : "No"));
        show("Is lucky", String.valueOf(race.getIsLucky() ? "Yes" : "No"));
        show("Can move through larger creature", String.valueOf(race.getCanMoveThroughLargerCreature() ? "Yes" : "No"));
        show("Can hide when obscured by larger creature", String.valueOf(race.getCanHideWhenObscuredByLargerCreature() ? "Yes" : "No"));

        show("Ability adjustments", race.getGrantedAbilityAdjustments().toString());
        show("Languages", race.getGrantedLanguages().toString());
        show("ST advantages", race.getGrantedSavingThrowAdvantages().toString());
        show("Focused ST advantages", race.getGrantedFocusedSavingThrowAdvantages().toString());
        show("Resistances", race.getGrantedResistances().toString());
        show("Immunities", race.getGrantedImmunities().toString());
        show("Skill proficiencies", race.getGrantedSkillProficiencies().toString());
        show("Focused skill proficiencies", race.getGrantedFocusedSkillProficiencies().toString());
        show("Armor proficiencies", race.getGrantedArmorProficiencies().toString());
        show("Weapon proficiencies", race.getGrantedWeaponProficiencies().toString());

        show("Cantrip slots", String.valueOf(race.getCantripSlots()));
        show("Ability for cantrip", String.valueOf(race.getAbilityForCantrip() == null ? "N/A" : race.getAbilityForCantrip()));
        show("Spell category for cantrip", String.valueOf(race.getSpellCategoryForCantrip() == null ? "N/A" : race.getSpellCategoryForCantrip()));

        show("Tool proficiency slots", String.valueOf(race.getToolProficiencySlots()));
        show("Offered tool proficiencies", race.getOfferedToolProficiencies().toString());
        show("Tool proficiencies", race.getGrantedToolProficiencies().toString());
        show("Special traits", race.getGrantedSpecialTraits().toString());
        
    }

    private static void show(String propertyName, String propertyValue) {
        System.out.println(propertyName + ": " + propertyValue);
    }
    
}
