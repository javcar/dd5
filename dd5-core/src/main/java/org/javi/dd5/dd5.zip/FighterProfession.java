package org.javi.dd5;

import java.util.ArrayList;

public class FighterProfession extends Profession {

    public FighterProfession() {
        
        setHitDice(10);

        getGrantedPrimaryAbilities().add(Ability.Strength);

        getGrantedSavingThrowProficiencies().add(Ability.Strength);
        getGrantedSavingThrowProficiencies().add(Ability.Constitution);
        
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Light));
        getGrantedArmorProficiencies().addAll(Armor.getArmors(ArmorCategory.Medium));

        setGrantedShieldProficiency(true);

        getGrantedWeaponProficiencies().addAll(Weapon.getWeapons(WeaponCategory.Simple));
        getGrantedWeaponProficiencies().addAll(Weapon.getWeapons(WeaponCategory.Martial));

    }
    
}