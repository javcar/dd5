package org.javi.dd5;

public class HalfOrcRace extends Race {

    public HalfOrcRace() {

        setDarkVisionRange(60);
        setAdultAge(14);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Strength, +2);
        getGrantedAbilityAdjustments().put(Ability.Constitution, +1);

        /* Languages */
        grantLanguages();

        /* Other traits */
        Menacing();
        grantRelentlessEndurance();
        grantSavageAttacks();

    }

    private void Menacing() {
        getGrantedSkillProficiencies().add(Skill.Intimidation);
    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);
        getGrantedLanguages().add(Language.Orc);
    }

    private void grantRelentlessEndurance() {
        getGrantedSpecialTraits().add(new RelentlessEnduranceSpecialTrait());
    }

    private void grantSavageAttacks() {
        getGrantedSpecialTraits().add(new SavageAttacksSpecialTrait());
    }
    
}