package org.javi.dd5;

public class HalflingRace extends Race {

    public HalflingRace() {

        setSpeed(25);
        setSize(Size.Small);        
        setAdultAge(20);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Dexterity, +2);

        /* Languages */
        grantLanguages();

        /* Other traits */
        grantLucky();
        grantBrave();
        grantHalflingNimbleness();

    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);
        getGrantedLanguages().add(Language.Halfling);
    }

    private void grantLucky() {
        setIsLucky(true);
    }

    private void grantBrave() {
        getGrantedSavingThrowAdvantages().add(Damage.Fear);
    }

    private void grantHalflingNimbleness() {
        setCanMoveThroughLargerCreature(true);
    }
    
}