package org.javi.dd5;

public abstract class SpecialTrait {

    private Character character;    
    private int charges = 1;
    private Action actionCost;

    public Character getCharacter() {
        return this.character;
    }

    public void setCharacter(Character character) {
        this.character = character;
    }

    public int getCharges() {
        return this.charges;
    }

    public void setCharges(int charges) {
        this.charges = charges;
    }

    public Action getActionCost() {
        return this.actionCost;
    }

    public void setActionCost(Action actionCost) {
        this.actionCost = actionCost;
    }

    public boolean canActivate() {        
        return false;
    }

    public void activate() {        
        this.character.setHitPoints(1);
        this.charges -= 1;        
    }

    public boolean canRestore() {
        return false;
    }

    public void restore() {
        this.charges = 1;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }

}