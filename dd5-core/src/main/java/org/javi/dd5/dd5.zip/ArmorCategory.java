package org.javi.dd5;

public enum ArmorCategory {

    Light, Medium, Heavy;
    
}