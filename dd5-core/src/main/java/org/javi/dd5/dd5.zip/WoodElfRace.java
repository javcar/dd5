package org.javi.dd5;

public class WoodElfRace extends ElfRace {

    public WoodElfRace() {

        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Wisdom, +1);

        /* Other traits */
        grantElfWeaponTraining();
        grantFleetOfFoot();
        grantMaskOfTheWild();

    }

    private void grantElfWeaponTraining() {
        getGrantedWeaponProficiencies().add(Weapon.LongSword);
        getGrantedWeaponProficiencies().add(Weapon.ShortSword);
        getGrantedWeaponProficiencies().add(Weapon.ShortBow);
        getGrantedWeaponProficiencies().add(Weapon.LongBow);
    }

    private void grantFleetOfFoot() {
        setSpeed(35);
    }

    private void grantMaskOfTheWild() {
        setCanHideWhenLightlyObscuredByNaturalPhenomena(true);
    }
    
}