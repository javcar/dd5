package org.javi.dd5;

public class HumanRace extends Race {

    public HumanRace() {

        setAdultAge(18);

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Strength, +1);
        getGrantedAbilityAdjustments().put(Ability.Dexterity, +1);
        getGrantedAbilityAdjustments().put(Ability.Constitution, +1);
        getGrantedAbilityAdjustments().put(Ability.Intelligence, +1);
        getGrantedAbilityAdjustments().put(Ability.Wisdom, +1);
        getGrantedAbilityAdjustments().put(Ability.Charisma, +1);

        /* Languages */
        grantLanguages();

        /* Other traits */
        grantExtraLanguage();

    }

    private void grantLanguages() {
        getGrantedLanguages().add(Language.Common);        
    }

    private void grantExtraLanguage() {
        setLanguageSlots(1);
    }
    
}