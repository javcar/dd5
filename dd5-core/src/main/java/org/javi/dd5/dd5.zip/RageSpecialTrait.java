package org.javi.dd5;

public class RageSpecialTrait extends SpecialTrait {

    public RageSpecialTrait() {
        super();
        this.setActionCost(Action.Bonus);
    }
    
    @Override
    public boolean canActivate() {        
        return this.getCharges() > 0 && 
            this.getCharacter().getIsActionAvailable(this.getActionCost()) &&
            !Armor.getArmors(ArmorCategory.Heavy).contains(this.getCharacter().getArmorEquiped());
    }

    @Override
    public void activate() {
        
        this.getCharacter().getAvailableActions().remove(this.getActionCost());
        this.setCharges(this.getCharges() - 1);
    }

    @Override
    public boolean canRestore() {
        return this.getCharacter().getIsRested();
    }
    
}