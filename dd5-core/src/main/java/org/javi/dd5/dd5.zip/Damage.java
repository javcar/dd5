package org.javi.dd5;

public enum Damage {

    Poison, MagicalSleep,

    /* Condition */
    
    Charm,  /* Charmed */
    Fear    /* Frightened */
    ;
    
}