package org.javi.dd5;

public enum Language {

    Common, Dwarven, Elvish, Halfling, Gnomish, Orc;
    
}