package org.javi.dd5;

public class StoutHalflingRace extends HalflingRace {

    public StoutHalflingRace() {

        super();

        /* Ability adjustments */
        getGrantedAbilityAdjustments().put(Ability.Constitution, +1);

        /* Other traits */
        grantStoutResilience();

    }

    private void grantStoutResilience() {
        getGrantedSavingThrowAdvantages().add(Damage.Poison);
        getGrantedResistances().add(Damage.Poison);
    }
    
}