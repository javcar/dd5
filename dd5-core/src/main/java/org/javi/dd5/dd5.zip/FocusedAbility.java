package org.javi.dd5;

public class FocusedAbility {

    private Ability ability;
    private Focus focus;

    public FocusedAbility(Ability ability, Focus focus) {
        this.ability = ability;
        this.focus = focus;
    }

    public Ability getAbility() {
        return this.ability;
    }

    public Focus getFocus() {
        return this.focus;
    }

    public String toString() {
        return this.ability.toString() + " (" + this.focus.toString() + ")";
    }
    
}